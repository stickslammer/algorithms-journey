def count_divisibles():
    count = 0
    for i in range(1, 1001):
        if i % 3 == 0 and i % 5 == 0:
            count += 1
    return count

print(count_divisibles())  # Output: 66
