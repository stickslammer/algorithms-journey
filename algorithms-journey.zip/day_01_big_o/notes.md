# Day 1: Big-O Notation Basics

## Concepts:
- Big-O describes algorithm efficiency as input size grows.
- Common complexities: O(1), O(n), O(log n), O(n log n), O(n^2)

## Practice:
- Analyzed `find_duplicates()` — time: O(n), space: O(n)
- Implemented a `count_divisibles()` function — linear scan

## Reflection:
- Great start! Clear understanding of O(n)
